"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-14'
-------------------------------------------------------
"""
# Imports
from functions import is_palindrome
# Constants

s = input("Enter string: ")
palindrome = is_palindrome(s)
print("Palindrome:",palindrome)

