"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-14'
-------------------------------------------------------
"""
# Imports
from functions import max_diff
# Constants
s = " "
a = []
print("Press enter to stop.")
while s != "":
    s = input("Please input number: ")
    if s != "":
        a.append(int(s))
md = max_diff(a)
print(md)