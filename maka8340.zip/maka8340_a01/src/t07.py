"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-14'
-------------------------------------------------------
"""
# Imports
from functions import matrix_transpose
# Constants

a= [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]

s = " "
atemp = []
a = []
print("Press enter to go to next list.")
print("Type done to stop input")
while s != "done":
    s = input("Please input number: ")
    if s != "done" and s != "":
        atemp.append(int(s))
    else:
        a.append(atemp)
        atemp = []
        
b = matrix_transpose(a)

print(b)