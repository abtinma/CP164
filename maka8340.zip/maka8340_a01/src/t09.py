"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-14'
-------------------------------------------------------
"""
# Imports
from functions import pig_latin
# Constants

word = input("Enter Word: ")
pl = pig_latin(word)
print(f"Pig-Latin: {pl}")
