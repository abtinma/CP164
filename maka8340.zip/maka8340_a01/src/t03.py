"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-14'
-------------------------------------------------------
"""
# Imports
from functions import file_analyze
# Constants

fv = open("file.txt", "r", encoding="utf-8")
u, l, d, w, r = file_analyze(fv)

fv.close()

print(f"Number of uppercase:            {u}")
print(f"Number of lowercase:            {l}")
print(f"Number of digits:               {d}")
print(f"Number of whitespaces:          {w}")
print(f"Number of remaining characters: {r}")