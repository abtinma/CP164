"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-14'
-------------------------------------------------------
"""
# Imports
from functions import dsmvwl
# Constants

s = input("Please enter your sentence: ")


out = dsmvwl(s)

print(f"Disemvowelled: {out}")