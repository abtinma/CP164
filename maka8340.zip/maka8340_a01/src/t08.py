"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-14'
-------------------------------------------------------
"""
# Imports
from functions import  matrix_stats
# Constants


a = [[2, 0, -1, 1], [10, 4, -5, 9], [-6, 3, 6, 0]]

s = " "
atemp = []
a = []
print("Press enter to go to next list.")
print("Type done to stop input")
while s != "done":
    s = input("Please input number: ")
    if s != "done" and s != "":
        atemp.append(int(s))
    else:
        a.append(atemp)
        atemp = []

small, large, total, average = matrix_stats(a)

print(f"a: {a}")
print(f"Result: {small}, {large}, {total}, {average}")