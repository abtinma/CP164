"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-14'
-------------------------------------------------------
"""
# Imports
from functions import is_leap_year
# Constants

year = int(input("Please enter year: "))

leap_year = is_leap_year(year)

if leap_year == True:
    print(f"{year} is a leap year!")
else:
    print(f"{year} is not a leap year.")