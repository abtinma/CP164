"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-28'
-------------------------------------------------------
"""
# Imports
from functions import reroute
# Constants


opstring = input("Enter opstring: ")

values_in = [1, 2, 3, 4]

values_out = reroute(opstring, values_in)

print(values_out)