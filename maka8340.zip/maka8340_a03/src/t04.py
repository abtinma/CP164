"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-28'
-------------------------------------------------------
"""
# Imports
from Stack_array import Stack
from utilities import array_to_stack
# Constants

source = Stack()
source1 = [1, 2, 3, 4, 5, 6]

print(source1)
array_to_stack(source, source1)

source.reverse()


while source.is_empty() == False:
    value = source.pop()
    print(value)