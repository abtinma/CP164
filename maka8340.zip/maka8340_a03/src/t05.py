"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-28'
-------------------------------------------------------
"""
# Imports
from functions import is_palindrome_stack
# Constants


string = input("Enter a string: ")

palindrome = is_palindrome_stack(string)

print(palindrome)