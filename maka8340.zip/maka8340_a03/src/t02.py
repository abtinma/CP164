"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-28'
-------------------------------------------------------
"""
# Imports
from Stack_array import Stack
from utilities import array_to_stack
# Constants

source1 = Stack()
source2 = Stack()

array_to_stack(source1, [1, 2, 3, 4, 5, 6])
array_to_stack(source2, [7, 8, 9 ,10, 11, 12])

target = Stack()
target.combine(source1, source2)

while target.is_empty() == False:
    value = target.pop()
    print(value)