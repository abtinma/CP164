"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-21'
-------------------------------------------------------
"""
from Food_utilities import read_foods, food_table

file = open('foods.txt', "rt")
foods = read_foods(file)
file.close()

food_table(foods)
