"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-21'
-------------------------------------------------------
"""
from Food import Food
from Food_utilities import read_foods, calories_by_origin

file = open('foods.txt', "rt")
foods = read_foods(file)
file.close()

origin = int(input(f"Enter a origin as an int\n{Food.origins()}: "))
a = calories_by_origin(foods, 2)

print(f"Average Calories of {Food.ORIGIN[origin]} foods: {a}")