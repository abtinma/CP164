"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-21'
-------------------------------------------------------
"""
from Food_utilities import read_foods, average_calories

file = open('foods.txt', "rt")
foods = read_foods(file)
file.close()

avg = average_calories(foods)

print(f"Average Calories of all foods: {avg}")