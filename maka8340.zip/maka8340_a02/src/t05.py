"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-21'
-------------------------------------------------------
"""
from Food import Food
from Food_utilities import read_foods, food_table, food_search

file = open('foods.txt', "rt")
foods = read_foods(file)
file.close()

origin = int(input(f"Enter a origin as an int\n{Food.origins()}: "))
max_cals = int(input(f"Enter the maximum amount of calories: "))
is_veg = input(f"Is it a vegetable? [Y/N]: ")
if is_veg.upper() == "Y":
    is_veg = True
else:
    is_veg = False

results = food_search(foods, origin, max_cals, is_veg)

food_table(results)