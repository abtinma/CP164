"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-02-04'
-------------------------------------------------------
"""
# Imports
from Queue_circular import Queue

q = Queue(3)
print("Length of queue", len(q))
print("Is queue empty?", q.is_empty())
print("Is queue full?", q.is_full())

q.insert(100)
q.insert(200)
print("Length of queue", len(q))

value = q.peek()
print(value)

removed = q.remove()
print(removed)

q.insert(300)
q.insert(400)
print("Is queue full?", q.is_full())


