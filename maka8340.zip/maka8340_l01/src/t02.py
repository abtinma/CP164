"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-14'
-------------------------------------------------------
"""
# Imports
from Food import Food
# Constants

Ravioli = Food('Ravioli', 7, False, 246)

print(Ravioli)