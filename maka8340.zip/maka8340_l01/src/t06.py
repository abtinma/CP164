"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-14'
-------------------------------------------------------
"""
# Imports
from Food_utilities import read_food
from Food_utilities import write_foods


# Constants

file = open("new_foods.txt", "wt")

panzerotti = read_food('Panzerotti|7|False|770')

write_foods(file, [panzerotti])

file.close()

