"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-14'
-------------------------------------------------------
"""
# Imports
from Food_utilities import read_foods

# Constants


fv = open("foods.txt", "r")
foods = read_foods(fv)
fv.close()

for i in foods:
    print(i, end="\n\n")
    

    


