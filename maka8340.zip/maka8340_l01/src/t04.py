"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-14'
-------------------------------------------------------
"""
# Imports
from Food_utilities import read_food

# Constants

line = input("Enter food details: ")
f = read_food(line)

print(f)

