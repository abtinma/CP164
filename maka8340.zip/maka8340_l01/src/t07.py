"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-14'
-------------------------------------------------------
"""
# Imports
from Food_utilities import read_foods
from Food_utilities import get_vegetarian
# Constants


file = open('foods.txt', "rt")
foods = read_foods(file)
file.close()

veggies = get_vegetarian(foods)

for food in veggies:
    print(f"{food}\n")