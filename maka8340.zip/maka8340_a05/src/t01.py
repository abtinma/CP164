"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-02-12'
-------------------------------------------------------
"""
# Imports
from Food import Food
from Food_utilities import read_food, read_foods
from List_array import List
from utilities import array_to_list


file = open("foods.txt", "rt")
foods = read_foods(file)
file.close()


list1 = List()

array_to_list(list1, foods)

crepe = Food("Crepe", 7, True, 186)
list1.append(crepe)

for i in list1:
    print(f"{i.name}, {list1.count(i)}")

list1.clean()

print("------")
for i in list1:
    print(f"{i.name}, {list1.count(i)}")

temp = [read_food("Natto|6|True|212"), read_food("Fettuccine|7|False|266")]

list2 = List()
list2.append(temp[0])
list2.append(temp[1])

list3 = List()
list3.combine(list1, list2)

print("------")
for i in list3:
    print(f"{i.name}")

print("------")
print(list3[1])

list2.append(temp[0])
list2.append(temp[1])

list4 = List()
list4.intersection(list2, list3)

print("------")
for i in list4:
    print(f"{i.name}")

print("------")
print(list4.is_identical(list2))

list4.prepend(temp[0])

print("------")
for i in list4:
    print(f"{i.name}")

list4.remove_front()

print("------")
for i in list4:
    print(f"{i.name}")

list4.append(temp[0])
list4.remove_many(temp[0])

print("------")
for i in list4:
    print(f"{i.name}")

target1, target2 = list3.split()

print("------")
for i in target1:
    print(f"{i.name}")

print("------")
for i in target2:
    print(f"{i.name}")

target3, target4 = target1.split_alt()

print("------")
for i in target3:
    print(f"{i.name}")

print("------")
for i in target4:
    print(f"{i.name}")

list3.union(target3, target4)

print("------")
for i in list3:
    print(f"{i.name}")