"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-02-05'
-------------------------------------------------------
"""
# Imports
from List_array import List

list1 = List()

list1.append(1)
list1.append(2)
list1.append(3)
list1.append(3)

print(list1.index(2))

print(list1.find(1))

num = int(input("Enter number to check if it's in the list: "))
if num in list1:
    print(num, "is in list")
else:
    print(num, "is not in list")

num = int(input("Enter number to check how many of it is in the list: "))
print(f"Number of {num}s in the list: {list1.count(3)}")

print("Min of the list:", list1.min())
print("Max of the list:", list1.max())

