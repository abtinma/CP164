"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-02-05'
-------------------------------------------------------
"""
# Imports
from List_array import List

list1 = List()

list1.append(1)
print("Length of list:", len(list1))

list1.insert(0, 2)
print("Length of list:", len(list1))

print("Peek:", list1.peek())

remove = list1.remove(2)
print("Removing number", remove)


print("Peek:", list1.peek())


