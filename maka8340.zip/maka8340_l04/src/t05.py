"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-02-05'
-------------------------------------------------------
"""
# Imports
from List_array import List

list1 = List()

list1.append(1)
list1.append(2)
list1.append(3)
list1.append(3)

print("List1[0] =", list1[0])

list1[0] = 2

print("List1[0] =", list1[0])

