"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-02-05'
-------------------------------------------------------
"""
# Imports
from List_array import List

list1 = List()

list1.append(3)
list1.append(2)
list1.append(1)
index = list1.index(1)


print("Location of number on the list:",index)

