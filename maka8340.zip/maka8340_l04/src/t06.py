"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-02-05'
-------------------------------------------------------
"""
# Imports
from List_array import List
from utilities import array_to_list, list_to_array

list = List()

source = [1, 2, 3]

array_to_list(list, source)

print("Array to list: ")
for value in list:
    print(value)

list_to_array(list, source)

print()
print("List to array: ")
for value in source:
    print(value)

