"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-02-05'
-------------------------------------------------------
"""
# Imports
from Food import Food


food = Food("Lasagna", 7, False, None)
print(food) 