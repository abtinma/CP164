"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-29'
-------------------------------------------------------
"""
# Imports
from Food_utilities import read_foods
from Priority_Queue_array import Priority_Queue
from utilities import array_to_pq
from utilities import pq_to_array
from utilities import priority_queue_test



pq = Priority_Queue()
source = [1, 2, 3, 4, 5, 6]

array_to_pq(pq, source)

while not pq.is_empty():
    value = pq.remove()
    print(value)
    source.append(value)

pq_to_array(pq, source)

file_variable = open("foods.txt", "rt")
foods = read_foods(file_variable)
file_variable.close()

priority_queue_test(foods)


