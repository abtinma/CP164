"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-29'
-------------------------------------------------------
"""
# Imports
from Queue_array import Queue
from utilities import array_to_queue 
from utilities import queue_to_array 
from utilities import queue_test



queue = Queue()
source = [1, 2, 3, 4, 5, 6]

array_to_queue(queue, source)

for i in range(len(queue)):
    value = queue.remove()
    print(value)
    source.append(value)

print("Source:", source)

queue_test(source)


