"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-29'
-------------------------------------------------------
"""
# Imports
from Queue_array import Queue


value = input("Enter any value: ")

queue = Queue()
queue.insert(value)

print(queue.peek())