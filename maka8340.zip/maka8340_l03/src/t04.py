"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-29'
-------------------------------------------------------
"""
# Imports
from Priority_Queue_array import Priority_Queue


value = int(input("Enter any value: "))

pq = Priority_Queue()
pq.insert(value)

print(pq.peek())

