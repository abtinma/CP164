"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-22'
-------------------------------------------------------
"""
from utilities import stack_test

source = list(range(1, 11))

stack_test(source)