"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Abtin Makariaghdam
ID:      210768340
Email:   maka8340@mylaurier.ca
__updated__ = '2022-01-22'
-------------------------------------------------------
"""
from Food_utilities import read_foods
from utilities import stack_test

file = open('foods.txt', "rt")
foods = read_foods(file)
file.close()

stack_test(foods)